# Dependances :

- nodejs
- npm

# execution :
dans un terminal :
1. cd dans le dossier
2. `npm i`
3. `npm run dev`