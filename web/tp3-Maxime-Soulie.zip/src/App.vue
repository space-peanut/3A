<script setup lang="ts">
import liste from './components/Liste.vue'
</script>

<template>
  <liste msg="Vite + Vue" />
</template>

<style scoped>
</style>./components/Liste.vue
